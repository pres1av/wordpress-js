<?php
backupbuddy_core::verifyAjaxAccess();


// Server info page extended PHPinfo thickbox.

/* phpinfo()
 *
 * Server info page phpinfo button.
 *
 */

phpinfo();
die();