<header class="header header__menu-full">
    <div class="container">
        <div id="top-menu" class="nav-menu nav-menu--horiz group">
        	<?php wp_nav_menu( array('menu' => 'Top Menu' )); ?>
        </div>
    </div>
</header>
