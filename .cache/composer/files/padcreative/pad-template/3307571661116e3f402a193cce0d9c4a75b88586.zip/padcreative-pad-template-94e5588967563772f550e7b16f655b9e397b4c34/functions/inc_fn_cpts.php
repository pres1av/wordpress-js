<?php

	// Uncomment add_action below to activate
	
	//add_action('init', 'pad_register_custom_post_type');
	
	if( !function_exists( 'pad_register_custom_post_type' ) ) {
	 
		function pad_register_custom_post_type() {
		 
			$labels = array(
				'name' => _x('Services', 'post type general name', pad_text_domain()),
				'singular_name' => _x('Service', 'post type singular name', pad_text_domain()),
				'add_new' => _x('Add New', 'Service', pad_text_domain()),
				'add_new_item' => __('Add New Service', pad_text_domain()),
				'edit_item' => __('Edit Service', pad_text_domain()),
				'new_item' => __('New Service', pad_text_domain()),
				'view_item' => __('View Service', pad_text_domain()),
				'search_items' => __('Search Services', pad_text_domain()),
				'not_found' =>  __('Nothing found', pad_text_domain()),
				'not_found_in_trash' => __('Nothing found in Trash', pad_text_domain()),
				'parent_item_colon' => ''
			);
		 
			$args = array(
				'labels' => $labels,
				'public' => true,
				//'publicly_queryable' => true,
				'show_ui' => true,
				//'show_in_menu' => true,
				'query_var' => true,
				'menu_icon' => get_template_directory_uri() . '/images/icon_wp_plus.png',
				//'rewrite' => array("slug" => "portfolio", "with_front" => true), // Permalinks format
				
				'rewrite' => array(
			        'slug'=>'services', //THIS CANT BE THE SAME AS A PAGE SLUG
			        'with_front'=> false,
			        'feed'=> true,
			        'pages'=> true
			    ),
				
				//'taxonomies' => array('service_type'),
				'capability_type' => 'post',
				'hierarchical' => true,
				'has_archive' => false,
				//'menu_position' => null,
				'supports' => array('title','editor')
			  ); 
		 
			register_post_type( 'services' , $args );
			
			// Register Custom Taxonomy
			
			$tax_name = _x('Sectors', 'taxonomy general name', pad_text_domain());
			$tax_singular = _x('Sector', 'taxonomy singular name', pad_text_domain());
			
			$tax_labels = [
				'name' => $tax_name,
				'singular_name' => $tax_singular,
				//'menu_name' => $tax_name,
				'all_items' => __('All ', pad_text_domain()) . $tax_name,
				'edit_item' => __('Edit ', pad_text_domain()) . $tax_singular,
				'view_item' => __('View ', pad_text_domain()) . $tax_singular,
				'update_item' => __('Update ', pad_text_domain()) . $tax_singular,
				'add_new_item' => __('Add New ', pad_text_domain()) . $tax_singular,
				'new_item_name' => _x('New ', 'new category name', pad_text_domain()) . $tax_singular . _x(' Name', 'new category name', pad_text_domain()),
				'parent_item' => __('Parent ', pad_text_domain()) . $tax_singular,
				'parent_item_colon' => __('Parent ', pad_text_domain()) . $tax_singular . ':',
				'search_items' => __('Search ', pad_text_domain()) . $tax_name,
				'popular_items' => __('Popular ', pad_text_domain()) . $tax_name,
				'separate_items_with_commas' => _x('Separate ', 'separate categories with commas', pad_text_domain()) . lcfirst($tax_name) . _x(' with commas', 'separate categories with commas', pad_text_domain()),
				'add_or_remove_items' => __('Add or remove ', pad_text_domain()) . lcfirst($tax_name),
				'choose_from_most_used' => __('Choose from most used ', pad_text_domain()) . lcfirst($tax_name),
				'not_found' => _x('No ', 'no categories found', pad_text_domain()) . lcfirst($tax_name) . _x(' found', 'no categories found', pad_text_domain()),
				'back_to_items' => _x('← Back to ', 'back to categories', pad_text_domain()) . lcfirst($tax_name)
			];
			
			register_taxonomy("sectors", array( "services"), 
				array(
					"hierarchical" => false, 
					"labels" => $tax_labels, 
					"show_ui" => true, 
					'query_var' => true, 
					'rewrite' => array('slug' => 'sector', 'hierarchical' => true, "with_front" => FALSE)
				)
			);
		
			// Only uncomment next line for development, otherwise always comment out.
			//flush_rewrite_rules();
			
		}
	}

?>