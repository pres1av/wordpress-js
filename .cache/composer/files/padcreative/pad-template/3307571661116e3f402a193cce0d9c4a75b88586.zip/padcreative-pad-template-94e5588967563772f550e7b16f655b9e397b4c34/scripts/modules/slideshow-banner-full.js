// -----------------------------------------------------------------------------
// module-slideshow-banner-full-screen
// -----------------------------------------------------------------------------

export const modules = {
	slideshowBannerFull: $('.slideshow-banner--full-screen'),
    smoothScroller: $("#module-slideshow-banner-full-screen-scroller a"),
    smoothScrollingAnchor: $('#module-slideshow-banner-full-screen-scroll-down-anchor')
}
    				
export const changeHeight = (event = '', slideshowBannerFull = modules.slideshowBannerFull) => {
    const winHeight = $(window).height();
    const minusHeight = slideshowBannerFull.offset().top;
                
    slideshowBannerFull.height(winHeight - minusHeight);
}

// Smooth scrolling button
export const smoothScrolling = (event = '', scroller = modules.smoothScroller, anchor = modules.smoothScrollingAnchor) => {

    scroller.click(event => {

        event.preventDefault();
    
        // Using jQuery's animate() method to add smooth page scroll
        // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
        $('html, body').animate({
                scrollTop: anchor.offset().top
            }, 800, function(){
        });
      
    });
}

// Offset for scroll to anchor tag
        
export const anchorOffsetHeight = (event = '', headerScrollingHeight = 90, smoothScrollingAnchor = modules.smoothScrollingAnchor) => {
        
    const wpAdminBar = $('#wpadminbar').height();
    const anchorOffset = wpAdminBar + headerScrollingHeight;
    
    smoothScrollingAnchor.css('bottom',anchorOffset);
    
}