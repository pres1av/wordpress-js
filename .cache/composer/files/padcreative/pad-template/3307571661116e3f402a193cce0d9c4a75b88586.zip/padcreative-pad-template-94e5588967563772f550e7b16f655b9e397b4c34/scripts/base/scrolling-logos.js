import { slick } from 'slick-carousel';
import { classes } from './base';

export const elements = {
	scrollingLogos: $('#scrolling-logos'),
	scrollingLogosInner: $('#scrolling-logos-inner')
}

// Enable scrolling logos on an element
export const scrollingLogosEnable = (parent = elements.scrollingLogos, child = elements.scrollingLogosInner, displayNone = classes.displayNone) => {

	parent.removeClass(displayNone);
    
    child.not('.slick-initialized').slick({
    	infinite: true,
    	slidesToShow: 4,
    	slidesToScroll: 1,
    	autoplay: true,
    	autoplaySpeed: 2000,
    	pauseOnHover: true,
    	appendArrows: parent,
    	prevArrow: '<a class="prev-next" id="prev"></a>',
    	nextArrow: '<a class="prev-next" id="next"></a>',
    	responsive: [
    	    {
    	      breakpoint: 930,
    	      settings: {
    	        slidesToShow: 3,
    	      }
    	    },
    	    {
    	      breakpoint: 738,
    	      settings: {
    	        slidesToShow: 2,
    	      }
    	    },
    	    {
    	      breakpoint: 486,
    	      settings: {
    	        slidesToShow: 1,
    	      }
    	    }
    	]
    });	
}