// -----------------------------------------------------------------------------
// module-fixed-header + module-fixed-header-overlay
// -----------------------------------------------------------------------------

import { classes } from '../base/base';

// Module elements
export const headerFixed = $('.header__fixed');

export const headerHeightScroll = (event = '', header = headerFixed, scrolling = classes.scrolling) => {
    let headerOffset = header.offset().top;
    
    const wpAdminBar = $('#wpadminbar');

    if (wpAdminBar.length) headerOffset -= wpAdminBar.height();

    if( headerOffset > 0 ) {
        header.addClass(scrolling);
    } else {
        header.removeClass(scrolling);
    }
}