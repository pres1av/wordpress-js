import { elements as base, classes } from './base';

export const elements = {
	topMenu: $('#top-menu'),
	topMenuString: '.menu-top-menu-container',
	responsiveBar: $('#responsive-bar'),
	responsiveMenu: $('#responsive-menu'),
	responsiveMenuButton: $('#responsive-menu-button')
}

// Breakpoints
export const breakpoints = {
	small: '25em',					//400px
	phone: '37.5em',				//600px
	tabletPortrait: '56.25em',		//900px
	tabletLandscape: '80em', 		//1280px
	desktop: '100em',				//1600px
	bigDesktop: '112.5em', 			//1800px
	hd:  '120em',					//1920px
	qhd: '160rem',					//2560px
	qhdp: '180rem',					//2880px
	msb: '202.5em',					//3240px
	uhd: '240em',					//3840px
	fourK: '256em',					//4096px
	fiveK: '320em'					//5120px
}
	
// Responsive menu and bar toggles
export const elementsToggle = (event = '', bar = elements.responsiveBar, menu = elements.responsiveMenu, button = elements.responsiveMenuButton, activate = classes.activate, scroll = classes.scroll, displayNone = classes.displayNone) => {

    button.click(e => {
	    
	    menu.toggleClass(activate);
	    button.toggleClass(activate);
	    
	    base.html.toggleClass(scroll);
	    base.body.toggleClass(scroll);
	    
	    e.stopPropagation();

	});
	
	// Close menu on click outside
	base.html.mouseup(e => {
	    const target = $(e.target).closest(menu);
		const targetButton = $(e.target).closest(button)
	    	
	    if ( !target.is(menu) && !targetButton.is(button) ) {
			menu.removeClass(activate);
			button.removeClass(activate);
				
			base.html.removeClass(scroll);
			base.body.removeClass(scroll);
	    }
    });
}

export const widthChecker = (event = '', breakpoint = breakpoints.tabletPortrait, topMenuString = elements.topMenuString, topMenu = elements.topMenu, bar = elements.responsiveBar, menu = elements.responsiveMenu, button = elements.responsiveMenuButton, activate = classes.activate, displayNone = classes.displayNone) => {

	// Set the responsive bar and menu breakpoint in ems | 1em = 16px => 900px/16px = 56.25em
	const mediaQueryList = window.matchMedia(`(max-width: ${breakpoint})`);
    
	menu.removeClass(activate);
    		
    if ( mediaQueryList.matches ) {
    		
		bar.add(menu).add(button).removeClass(displayNone);

    	topMenu.children(topMenuString).appendTo(menu);
    			
    			
    } else {
    			
    	bar.add(menu).add(button).addClass(displayNone);

    	menu.children(topMenuString).appendTo(topMenu);
    			
    } 
}