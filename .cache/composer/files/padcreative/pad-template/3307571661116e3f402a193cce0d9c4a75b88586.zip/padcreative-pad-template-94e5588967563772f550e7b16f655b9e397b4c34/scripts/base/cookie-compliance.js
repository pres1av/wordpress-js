﻿import { elements } as resElements from './responsive';

export const cookie = {	
	displayMsg: $('#cookieMessageWrapper'),
	fixedHeaderOverlay: $('#module-fixed-header-overlay'),
	extraSpaceClass: 'top-extra-space',
	menuExtraClass: 'menu-top-extra'
}

// Create cookie function
const createCookie = (name, value, days) => {
	if (days) {
		let date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		const expires = `expires=${date.toGMTString()}`;
	}
	else var expires = '';
	document.cookie = `${name}=${value}; ${expires}; path=/`;
}

// Read cookie function
const readCookie = name => {
	const nameEQ = `${name}=`;
	const ca = document.cookie.split(';');
	ca.forEach(el => {
		while (el.charAt(0) == ' ') el = el.substring(1, el.length);
		if (el.indexOf(nameEQ) == 0) return el.substring(nameEQ.length, el.length);
	}
	return null;
}

// Erase cookie function
const eraseCookie = name => createCookie(name, '', -1);

//Site Specific Classes to Toggle
const toggleCookieClasses = (flag, fixedHeaderOverlay, bar, menu, extraSpace, menuExtra) => {
	fixedHeaderOverlay[flag + 'Class'](extraSpace);
	bar[flag + 'Class'](extraSpace);
	menu[flag + 'Class'](menuExtra);
}


// -----------------------------------------------------------------------------
// Main Cookie Compliance function
// -----------------------------------------------------------------------------
 
export const cookieCompliance = (strCookieName = 'cookie-compliance', strApprovedVal = 'approved', displayMsg = cookie.displayMsg, fixedHeaderOverlay = cookie.fixedHeaderOverlay, bar = resElements.responsiveBar, menu = resElements.responsiveMenu, extraSpace = cookie.extraSpaceClass, menuExtra = cookie.menuExtraClass) => {
	
	const cookieVal = readCookie(strCookieName);
	
	if (cookieVal != strApprovedVal) {
		setTimeout(function() { displayMsg.slideDown(200); }, 200);
		toggleCookieClasses('add', fixedHeaderOverlay, bar, menu, extraSpace, menuExtra);
	} else if (!displayMsg.is(':hidden')) {
		displayMsg.slideUp();
		toggleCookieClasses('remove', fixedHeaderOverlay, bar, menu, extraSpace, menuExtra);
	};
	
	$('#cookieClose').click(function() {
		displayMsg.slideUp();
		toggleCookieClasses('remove', fixedHeaderOverlay, bar, menu, extraSpace, menuExtra);
		createCookie(strCookieName, strApprovedVal, 365);
	});
}