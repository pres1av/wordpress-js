// Main elements
export const elements = {
	html: $('html'),
	body: $('body'),
	formRequiredFields: $('.gravity-form .gfield_contains_required').find('input, textarea, select')
}

// Classes
export const classes = {
	activate: 'activate',
	scroll: 'scroll',
	scrolling: 'scrolling',
	displayNone: 'display-none'
}

// Get the current browser and version | output: Chrome 70
export const browserVersion = (() => {
    var ua = navigator.userAgent, tem, 
    M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if(/trident/i.test(M[1])){
        tem =  /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE '+(tem[1] || '');
    }
    if(M[1] === 'Chrome'){
        tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
        if(tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
    }
    M = M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, ' ?'];
    if((tem = ua.match(/version\/(\d+)/i))!= null) M.splice(1, 1, tem[1]);
    return M.join(' ');
})();

// Adds browser name and version as classes to body
export const bodyBrowserVersion = (version = browserVersion) => {
	const versionArr = version.split(' ');
	elements.body.addClass(`${versionArr[0]} ${versionArr[0]}${versionArr[1]}`);
}

// Add required attr to required form fields
export const setFormRequired = (fields = elements.formRequiredFields) => {
	fields.attr('required', true);
}