// -----------------------------------------------------------------------------
// module-slideshow-banner
// -----------------------------------------------------------------------------

import { cycle } from 'jquery.cycle2';
import { classes } from '../base/base';

export const modules = {
	slideshowBanner: $('.slideshow-banner'),
    slideshowBannerSlide: $('.slideshow-banner .slideshow-banner__slide')
}
    
export const slideshowBannerCycle = (slideshowBanner = modules.slideshowBanner, slide = modules.slideshowBannerSlide, displayNone = classes.displayNone) => {
	slide.removeClass(displayNone);
	
	slideshowBanner.cycle({
		slides: '> div',
	    speed: 1500,
	    timeout: 3000,
	    fx: 'fade'
    });
}