<?php
/*
Template Name: Posts Template
*/
?>
<?php get_header(); ?>



<!-- index.php -->



<main class="posts">

	<?php /*<div class="section padding-top padding-bottom">
		<div class="container">
					
			<div class="row">
			
				<div class="col-sm-6 col-md-8">
								
					<?php get_template_part( 'templates/component', 'loop-archives' ); ?>
					
				</div>
				
				<div class="col-sm-6 col-md-4">
				
					<?php get_template_part( 'templates/sidebars/panel', 'blog' ); ?>
					
				</div>
				
			</div>
		
		</div>
	</div> */ ?>
	<section id="news-new" class="main-content padding-top padding-bottom">
		<div class="container">
			
			<div class="row">
			
				<div class="col-xs-12">
				
				
					<h1>News</h1>
				
				
				</div>
			</div>
					
			<?php get_template_part( 'templates/component', 'loop-archives-new' ); ?>
			
	
		</div>
		
	</section>
					
	
</main>

<?php get_footer(); ?>