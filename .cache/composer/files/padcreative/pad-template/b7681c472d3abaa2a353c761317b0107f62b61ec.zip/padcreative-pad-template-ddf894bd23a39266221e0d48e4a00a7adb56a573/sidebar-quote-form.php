<div class="gravity-form">
	
	<h3>Get In Touch</h3>
	
	<p>Please leave your details and we’ll be in touch</p>
	
	<?php gravity_form( 1, false, false, false, '', false ); ?>
	
</div>					
