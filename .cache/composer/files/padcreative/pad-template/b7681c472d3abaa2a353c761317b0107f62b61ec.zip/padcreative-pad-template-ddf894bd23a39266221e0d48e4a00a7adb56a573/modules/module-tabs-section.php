<section class="section-tabs">
		
		<div class="container-fluid">
			
			<div class="row">
				
					<input id="tab-1" type="radio" name="tab-group" checked="checked"/>
					<label for="tab-1" class="section-tabs__label">Tab 1</label>
					
					<input id="tab-2" type="radio" name="tab-group" />
					<label for="tab-2" class="section-tabs__label">Tab 2</label>
					
					<input id="tab-3" type="radio" name="tab-group" />
					<label for="tab-3" class="section-tabs__label">Tab 3</label>
					
					<input id="tab-4" type="radio" name="tab-group" />
					<label for="tab-4" class="section-tabs__label">Tab 4</label>
					
					<input id="tab-5" type="radio" name="tab-group" />
					<label for="tab-5" class="section-tabs__label">Tab 5</label>
			
				<div class="section-tabs__container">
					
					<div id="content-1" class="container section-tabs__content">
					
						Content 1
						
					</div>
					
					<div id="content-2" class="container section-tabs__content">
					
						Content 2
						
					</div>
					
					<div id="content-3" class="container section-tabs__content">
					
						Content 3
						
					</div>
					
					<div id="content-4" class="container section-tabs__content">
						
						Content 4
						
					</div>
					
					<div id="content-5" class="container section-tabs__content">
					
						Content 5
											
					</div>
					
				</div>
				
			</div>

		</div>
		
	</section>