	<?php //To specify left and right form fields add these classes within the Gravity Form editor ?>
	
	
	<section class="form-section padding-top padding-bottom">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
    				
                    <div class="gravity-form group">
                    	
                    	<h3>Get In Touch</h3>
                    	
                    	<p>Please leave your details and we’ll be in touch</p>
                    	
                    	<?php gravity_form( 2, false, false, false, '', false ); ?>
                    	
                    </div>					
    				
				</div>
			</div>
		</div>
	</section>
