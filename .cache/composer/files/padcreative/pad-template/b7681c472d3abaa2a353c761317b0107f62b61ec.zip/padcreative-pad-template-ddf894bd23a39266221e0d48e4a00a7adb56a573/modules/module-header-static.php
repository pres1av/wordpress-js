	<header class="header header__static header__static--regular">
		
		<div class="container">
			
    		<div class="header__contact-box">
    			<p class="header__tel"><?php the_field('phone_number','options'); ?></p>
    			<p class="header__email"><?php the_field('email_address','options'); ?></p>
    		</div>
    		<div class="header__logo-box">
    			<a href="<?php echo home_url() ?>/" title="Go to the home page">
	    			<img class="header__logo" src="<?php //bloginfo('template_directory') ?>http://www.padcreative.co.uk/wp-content/themes/pad/images/logo_pad_creative.png" alt="Company Strapline">
	    		</a>
    		</div>
    	
    		<?php wp_nav_menu( ['block' => 'nav-menu', 'theme_location' => 'menu-top'] ); ?>
				
		</div>
		
	</header>
