<?php
	
	// Global text domain
	if( !function_exists( 'pad_text_domain' ) ) {
		
		function pad_text_domain() {
			return 'pad-template';
		}
		
	}
	
	require_once('functions/inc_fn_cpts.php');
	require_once('functions/inc_pad_register.php');
	require_once('functions/inc_pad_generic_functions.php');
	require_once( 'functions/inc_pad_register.php' );

	function pad_enqueue_styles() {
		
		//Enqueue
		wp_enqueue_script('jquery');
			    
		//Slick Plugin for carousels
		wp_enqueue_style( 'slick-styles' );
			    
		//Magnific Plugin for lightbox
		wp_enqueue_style( 'magnific-styles' );
			    
		//Original Lightbox Plugin
		//wp_enqueue_script('lightbox-js');
			    
		//Easing Plugin 
		//wp_enqueue_script( 'easing-js');
			    
		//Parallax Plugin 
		//wp_enqueue_script( 'parallax-js');
			    
		//Cookie Compliance Banner
	    //wp_enqueue_script( 'pad-cookie-banner' );
			    
	    //Pad Modules
	    //wp_enqueue_script( 'pad-modules' );
	            
		//Main Stylesheet and JS
		//wp_enqueue_script( 'ajax-load-more');
		//wp_enqueue_script('pad');
		$deps = array();
	    wp_enqueue_style( 'pad', get_stylesheet_directory_uri() . '/style.css', $deps );
	    $deps = array();
	    wp_enqueue_script( 'pad', get_stylesheet_directory_uri(). '/scripts/pad.js', $deps, false, true );

	    /*
	    global $wp_query;           
	    wp_localize_script( 'ajax-load-more', 'ajaxloadmore', array(
	    	'ajaxurl' => admin_url( 'admin-ajax.php' )
	    ));
	*/		
			
		// Adding WP REST API Authentication
	    //wp_localize_script( 'wp-api', 'wpApiSettings', [ 'root' => esc_url_raw( rest_url() ), 'nonce' => wp_create_nonce( 'wp_rest' ) ] );
	        
	    // Adding the site URL and template URL as a JS object. Usage in pad-javascript: wpURLs.site or wpURLs.template
	    wp_localize_script('pad', 'wpURLs', [ 'site' => home_url(), 'template' => get_bloginfo('template_directory') ]);
	
	}
	add_action( 'wp_enqueue_scripts', 'pad_enqueue_styles' );
	
	
	//========================================================================
	//! Includes
	//========================================================================

	
	// Get Query Variable
	function add_query_vars_filter( $vars ){
		$vars[] = "pg";
		return $vars;
	}
	add_filter( 'query_vars', 'add_query_vars_filter' );

	//========================================================================
	//! AJAX stuff
	//========================================================================
    
    //non logged in users
    add_action( 'wp_ajax_nopriv_ajax_load_more', 'ajax_load_more_posts' );
    //logged in users
    add_action( 'wp_ajax_ajax_load_more', 'ajax_load_more_posts' );
    
    
    
    function ajax_load_more_posts() {
        
        //prepare the query getting the page number which is posted to admin-ajax.php in ajax-load-more.js
        
        $query_vars['paged'] = $_POST['page'];
        $query_vars['post_type'] = 'post';
        $query_vars['posts_per_page'] = 6;
        
        //print_r($query_vars);

        $posts = new WP_Query( $query_vars );
        $GLOBALS['wp_query'] = $posts;
        
        $counter = 1;
        
        if( ! $posts->have_posts() ) { //if no more posts
            /*echo '<h2>'._e('No More Posts Found. Sorry.').'</h2>';*/
            echo '<script type="text/javascript">
            (function($) {
               //$("#load-more").addClass("display-none");
               $("#no-more-found").removeClass("display-none");               
            })(jQuery);
            </script>';
        } else {
            while ( $posts->have_posts() ) { //loop posts
                $posts->the_post();
                get_template_part( 'templates/ajax', 'post-content' );
                
				if($counter == 3):
				    echo '<div class="clearfix visible-md visible-lg"></div>';
				endif;
				
				
                
                $counter++;
            }
            
            
        }
    
    
        die();
        
        
    }

	//========================================================================
	//! Images
	//========================================================================
	
	// Params: Size Label, Width, Height, Crop? (optional)
	add_image_size( 'one-col', 300, 600 );
	add_image_size( 'two-col', 600, 960 );
	add_image_size( 'slides', 1600, 400, true );
	add_image_size( 'slides-full', 1920, 4000 );
	add_image_size( 'sliding-logos', 216, 65 );
	/*add_image_size( 'logo-parade', 160, 120 );
	add_image_size( 'article-thumb', 200, 300 );
	add_image_size( 'tiny-thumb', 80, 80, true );
	add_image_size( 'testimonials', 120, 120, true );*/
	
	add_image_size( 'post-thumb', 290, 290, true );
	add_image_size( 'sliding-thumbs', 290 );
	
	
	//========================================================================
	//! Transients
	//========================================================================
	
	// Flush Transient data when posts/pages are updated/published
	function clear_transients() {
	
		if ( get_current_post_type() == 'post' ) { 
		
			//delete_transient('query_name_here');
		}
		elseif( get_current_post_type() == 'page') {
			
			//delete_transient('query_name_here');
		}
		elseif( get_current_post_type() == 'testimonials') {
			
			delete_transient('query_home_random_testimonials');
		}
		elseif( get_current_post_type() == 'pad_portfolio') {
			
			delete_transient('query_portfolio_items');
			delete_transient('query_portfolio_items_by_type');
			delete_transient('query_portfolio_items_by_sector');
		}
	}
	add_action('save_post','clear_transients');
	
	
	//========================================================================
	//! Admin Area
	//========================================================================
	
	// Add Custom Stylesheets to WYSIWYG Editor 
	function my_mce_buttons_2( $buttons ) {
	    array_unshift( $buttons, 'styleselect' );
	    return $buttons;
	}
	add_filter( 'mce_buttons_2', 'my_mce_buttons_2' );
	
	function my_mce_before_init( $settings ) {
	
	    $style_formats = array(
	    	
	        array(
	        	'title' => 'Intro Paragraph',
	        	'block' => 'p',
	        	'classes' => 'intro'
	        )
			/*
	        array(
	    		'title' => 'Quote',
	    		'selector' => 'p',
	    		'classes' => 'quote'
	    	),
			array(
	        	'title' => 'Bigger, Bolder and Red',
	        	'inline' => 'span',
	        	'classes' => 'bold-red'
	        )
	        */
	    );
	
	    $settings['style_formats'] = json_encode( $style_formats );
	   
	    return $settings;
	}
	add_filter( 'tiny_mce_before_init', 'my_mce_before_init' );
	
	add_editor_style('editor_style.css');
	

	//========================================================================
	//! Theme Options
	//========================================================================
	
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	 
	if( !function_exists( 'pad_template_setup' ) ) {
		
		function pad_template_setup() {
			/*
			 * Make theme available for translation.
			 * Translations can be filed in the /languages/ directory.
			 */
			load_theme_textdomain( pad_text_domain(), get_template_directory() . '/languages' );
		
			/*
			 * Let WordPress manage the document title.
			 * By adding theme support, we declare that this theme does not use a
			 * hard-coded <title> tag in the document head, and expect WordPress to
			 * provide it for us.
			 */
			add_theme_support( 'title-tag' );
		
			/*
			 * Enable support for Post Thumbnails on posts and pages.
			 *
			 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
			 */
			add_theme_support( 'post-thumbnails' );
		
			register_nav_menu( 'menu-top', __('Top Menu' ) );
			register_nav_menu( 'footer', __('Footer') );
		
			/*
			 * Switch default core markup for search form, comment form, and comments
			 * to output valid HTML5.
			 */
			add_theme_support( 'html5', array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			) );
			
		}
		
	}
		
	add_action( 'after_setup_theme', 'pad_template_setup' );
	
	
	
	// Add Theme Support for the following features
	add_theme_support('menus');
	add_theme_support('post-thumbnails');
	add_theme_support( 'title-tag' );

	// Enable Editors to edit Menus
	$role_object = get_role( 'editor' );
	$role_object->add_cap( 'edit_theme_options' );
	
	

	//========================================================================
	//! Admin / User Logged In
	//========================================================================
	
	
	// Use this function to run tests on the website only visible to logged in admin (ie. Pete!). Use in true/false if statement.
	function only_show_if_admin_loggedin() {
		global $user_ID; 
				
		if( $user_ID ) { 
			if( current_user_can('level_10') ) { 
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else {
			return FALSE;
		}
	}
	
	function only_show_if_anyone_loggedin() {
		global $user_ID; 
				
		if( $user_ID ) { 
			if( current_user_can('read') ) { 
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else {
			return FALSE;
		}
	}
	
		
	/*Then wherever you are putting in code that you only want to show for logged-in admin users, just wrap it in this if statement...
		
	<?php if (only_show_if_admin_loggedin() == true) : ?> 
	
	<!-- Code Here -->
	
	<?php endif; ?> */
	
	
	//========================================================================
	//! Custom Password Form
	//========================================================================
	
	/*function my_password_form() {
	    global $post;
	    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
	    $o = '<form id="login-form" action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">
	    <p>' . __( "Please enter the password that you have been provided with:" ) . '</p>
		<h3>' . __( "Password:" ) . ' </h3><input class="case-input-field" name="post_password" id="' . $label . '" type="password" /><input class="case-input" type="submit" name="Submit" value="' . esc_attr__( "Submit" ) . '" />
	    </form>';
	    return $o;
	}
	add_filter( 'the_password_form', 'my_password_form' );*/
	
	//========================================================================
	//! Gravity Form Confirmation
	//========================================================================
	
	add_filter( 'gform_confirmation_anchor', '__return_true' );
	
	//========================================================================
	//! Custom ACF Options Pages
	//========================================================================
	
	if( function_exists('acf_add_options_page') ) {
	
		acf_add_options_page('General Website Content');
	
	}	
	
	
	//========================================================================
	//! Change Posts name
	//========================================================================
	
	
	function change_post_menu_text() {
		global $menu;
		global $submenu;
		
		// Change menu item
		$menu[5][0] = 'Blog';
		
		// Change post submenu
		$submenu['edit.php'][5][0] = 'Blog';
		$submenu['edit.php'][10][0] = 'Add Post';
	}
	
	add_action( 'admin_menu', 'change_post_menu_text' );		
	
	
	//========================================================================
	//! Sanitize function
	//========================================================================
	
	
	// Clean up user input – used by sanitize()
	function cleanInput($input) {
	
		$search = array(
			'@<script[^>]*?>.*?</script>@si',   // Strip out javascript
			'@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
			'@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
			'@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
		);

		$output = preg_replace($search, '', $input);
		return $output;
	}

	// Sanitize user input
	function sanitize($input) {
		if (is_array($input)) {
			foreach($input as $var=>$val) {
				$output[$var] = sanitize($val);
			}
		}
		else {
			if (get_magic_quotes_gpc()) {
				$input = stripslashes($input);
			}
			$output  = cleanInput($input);
		}
		return $output;
							
	}
	
	
	//========================================================================
	//! Woocommerce
	//========================================================================
	
	// Declare WooCommerce Compatibility and enable features you want to use
	//
	add_action( 'after_setup_theme', function() {
		add_theme_support( 'woocommerce' );
		//add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		//add_theme_support( 'wc-product-gallery-slider' );
	} );
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

?>