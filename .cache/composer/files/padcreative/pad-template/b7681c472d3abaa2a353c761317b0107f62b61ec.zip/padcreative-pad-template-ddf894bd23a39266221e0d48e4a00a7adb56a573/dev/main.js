// Base import
import * as base from '../node_modules/@padcreative/scripts/base/base';
import * as responsive from '../node_modules/@padcreative/scripts/base/responsive';
import { lightboxEnable } from '../node_modules/@padcreative/scripts/base/jquery-lightbox';
import { scrollingLogosEnable } from '../node_modules/@padcreative/scripts/base/scrolling-logos';
//import { cookieCompliance } from '../node_modules/@padcreative/scripts/base/cookie-compliance';

// Modules import
import { headerHeightScroll } from '../node_modules/@padcreative/scripts/modules/header-fixed';
import { slideshowBannerCycle } from '../node_modules/@padcreative/scripts/modules/slideshow-banner-cycle';
import * as slideshowBannerFull from '../node_modules/@padcreative/scripts/modules/slideshow-banner-full';

base.bodyBrowserVersion();
base.setFormRequired();
scrollingLogosEnable();

$(lightboxEnable);
$(responsive.widthChecker); 
$(responsive.elementsToggle);					
$(window).resize(responsive.widthChecker);

$(headerHeightScroll);
$(document).scroll(headerHeightScroll);
slideshowBannerCycle();
$(slideshowBannerFull.changeHeight);
$(slideshowBannerFull.smoothScrolling);
$(slideshowBannerFull.anchorOffsetHeight);