<div class="col-xs-12 col-sm-6 col-md-3">
        
    <a class="main-content__container-link" href="<?php the_permalink() ?>" title="Read full story">

        <div class="main-content__post-container">
            
            <?php if (has_post_thumbnail()) :  ?>
            
                <div class="main-content__image-box">
                    
                    <img src="<?php echo get_the_post_thumbnail_url(null, 'post-thumb'); ?>" alt="<?php the_title(); ?>" >
                    
                </div>
            
            <?php endif; ?>
            
            <h2 class="main-content__post-title"><?php the_title(); ?></h2>
            
            <?php echo excerpt(50) ?>
            
        </div>

    </a>

</div>
