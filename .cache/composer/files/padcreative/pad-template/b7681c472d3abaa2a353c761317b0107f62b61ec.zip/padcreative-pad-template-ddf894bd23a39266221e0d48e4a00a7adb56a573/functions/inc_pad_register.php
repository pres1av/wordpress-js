<?php       
	
	//========================================================================
	//! Register Stuff
	//========================================================================
	
	function pad_register_styles() {
	
		//Slick Plugin for carousels
	    $deps = array();
		wp_register_style( 'slick-styles',get_template_directory_uri().'/scripts/slick-1.9.0/slick.css', $deps );
	    $deps = array('jquery');
	    wp_register_script( 'slick-js', get_template_directory_uri().'/scripts/slick-1.9.0/slick.min.js', $deps, false, true );
	
	    //Magnific Plugin for lightbox
	    $deps = array();
		wp_register_style( 'magnific-styles',get_template_directory_uri().'/scripts/magnific-popup/dist/magnific-popup.css', $deps );
	    $deps = array('jquery');
	    wp_register_script( 'magnific-js', get_template_directory_uri().'/scripts/magnific-popup/dist/jquery.magnific-popup.js', $deps, false, true );
	    
	    //Original Lightbox Plugin 
	    $deps = array('jquery');
	    wp_register_script( 'lightbox-js', get_template_directory_uri().'/scripts/lightbox/jquery.lightbox.min.js', $deps, false, true );
	    
	    //Easing Plugin 
	    $deps = array('jquery');
	    wp_register_script( 'easing-js', get_template_directory_uri().'/scripts/jquery.easing.1.3.js', $deps, false, true );
	    
	    //Parallax Plugin 
	    $deps = array('jquery');
	    wp_register_script( 'parallax-js', get_template_directory_uri().'/scripts/parallax.min.js', $deps, false, true );
	    
	    //Cycle Plugin 
	    $deps = array('jquery');
	    wp_register_script( 'cycle2', get_template_directory_uri().'/scripts/jquery.cycle2.min.js', $deps, false, true );
	    
	    //Cookie Compliance Banner
		$deps = array(
			'jquery'
		);
	    wp_register_script( 'pad-cookie-banner', get_template_directory_uri().'/scripts/cookie-compliance.js', $deps, false, true );
	
	    //Pad Modules
		$deps = array(
			'jquery',
			'cycle2'
		);
	    wp_register_script( 'pad-modules', get_template_directory_uri().'/scripts/pad-modules.js', $deps, false, true );
	    
	    //Ajax
		$deps = array(
			'jquery'
		);
	    wp_register_script( 'ajax-load-more',  get_template_directory_uri().'/scripts/ajax-load-more.js', $deps, false, true );
	    
	
		//Main Stylesheet and JS
		$deps = array();
		wp_register_style( 'pad-old', get_template_directory_uri() . '/style.css', $deps );
		$deps = array(
			'jquery',
			//'wp-api',
			'magnific-js',
			'slick-js'
		);
	    wp_register_script( 'pad-old', get_template_directory_uri().'/scripts/pad-javascript.js', $deps, false, true );
	    
	}
    
    add_action( 'wp_enqueue_scripts', 'pad_register_styles' );