module.exports = function(api) {
  return {
    presets: [
      [
        "@babel/preset-env",
        {
          forceAllTransforms: api.env("production"),
        },
      ],
    ],
  };
};