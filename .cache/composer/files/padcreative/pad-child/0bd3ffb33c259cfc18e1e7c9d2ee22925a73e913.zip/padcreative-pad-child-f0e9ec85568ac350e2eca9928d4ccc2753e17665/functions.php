<?php
	
	require_once( get_template_directory() . '/functions/inc_pad_register.php' );

	function pad_enqueue_styles() {
		
		//Enqueue
		wp_enqueue_script('jquery');
			    
		//Slick Plugin for carousels
		wp_enqueue_style( 'slick-styles' );
			    
		//Magnific Plugin for lightbox
		wp_enqueue_style( 'magnific-styles' );
			    
		//Original Lightbox Plugin
		//wp_enqueue_script('lightbox-js');
			    
		//Easing Plugin 
		//wp_enqueue_script( 'easing-js');
			    
		//Parallax Plugin 
		//wp_enqueue_script( 'parallax-js');
			    
		//Cookie Compliance Banner
	    //wp_enqueue_script( 'pad-cookie-banner' );
			    
	    //Pad Modules
	    //wp_enqueue_script( 'pad-modules' );
	            
		//Main Stylesheet and JS
		//wp_enqueue_script( 'ajax-load-more');
		//wp_enqueue_script('pad');
		$deps = array();
	    wp_enqueue_style( 'pad-child', get_stylesheet_directory_uri() . '/style.css', $deps );
	    $deps = array();
	    wp_enqueue_script( 'pad-child', get_stylesheet_directory_uri(). '/scripts/dist/pad-javascript.js', $deps, false, true );

	    /*
	    global $wp_query;           
	    wp_localize_script( 'ajax-load-more', 'ajaxloadmore', array(
	    	'ajaxurl' => admin_url( 'admin-ajax.php' )
	    ));
	*/		
			
		// Adding WP REST API Authentication
	    //wp_localize_script( 'wp-api', 'wpApiSettings', [ 'root' => esc_url_raw( rest_url() ), 'nonce' => wp_create_nonce( 'wp_rest' ) ] );
	        
	    // Adding the site URL and template URL as a JS object. Usage in pad-javascript: wpURLs.site or wpURLs.template
	    wp_localize_script('pad', 'wpURLs', [ 'site' => home_url(), 'template' => get_bloginfo('template_directory') ]);
	
	}
	add_action( 'wp_enqueue_scripts', 'pad_enqueue_styles' );
	
	
	//========================================================================
	//! Site specific functions
	//========================================================================
	
	
	
	
	
	
	