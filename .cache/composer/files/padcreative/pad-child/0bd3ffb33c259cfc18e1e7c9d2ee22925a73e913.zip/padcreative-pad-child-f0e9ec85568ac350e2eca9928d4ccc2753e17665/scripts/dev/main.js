// Base import
import * as base from '../../../pad-template/scripts/base/base';
import * as responsive from '../../../pad-template/scripts/base/responsive';
import { lightboxEnable } from '../../../pad-template/scripts/base/jquery-lightbox';
import { scrollingLogosEnable } from '../../../pad-template/scripts/base/scrolling-logos';
//import { cookieCompliance } from '../../../pad-template/scripts/base/cookie-compliance';

// Modules import
import { headerHeightScroll } from '../../../pad-template/scripts/modules/header-fixed';
import { slideshowBannerCycle } from '../../../pad-template/scripts/modules/slideshow-banner-cycle';
import * as slideshowBannerFull from '../../../pad-template/scripts/modules/slideshow-banner-full';

base.bodyBrowserVersion();
base.setFormRequired();
scrollingLogosEnable();

$(lightboxEnable);
$(responsive.widthChecker); 
$(responsive.elementsToggle);					
$(window).resize(responsive.widthChecker);

$(headerHeightScroll);
$(document).scroll(headerHeightScroll);
slideshowBannerCycle();
$(slideshowBannerFull.changeHeight);
$(slideshowBannerFull.smoothScrolling);
$(slideshowBannerFull.anchorOffsetHeight);