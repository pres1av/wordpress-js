### 1.0.0: March 1st, 2016

* Initial plugin
