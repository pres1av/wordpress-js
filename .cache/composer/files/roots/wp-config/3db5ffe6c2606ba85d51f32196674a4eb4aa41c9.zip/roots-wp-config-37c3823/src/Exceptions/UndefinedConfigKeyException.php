<?php

namespace Roots\WPConfig\Exceptions;

class UndefinedConfigKeyException extends \RuntimeException
{
  
}
