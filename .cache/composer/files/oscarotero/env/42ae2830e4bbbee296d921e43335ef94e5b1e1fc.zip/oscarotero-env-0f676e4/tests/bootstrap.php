<?php

error_reporting(E_ALL);

include_once dirname(dirname(__FILE__)).'/src/Env.php';
